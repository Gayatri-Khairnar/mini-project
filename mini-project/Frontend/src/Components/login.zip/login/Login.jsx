import React, {useState}  from 'react';
import './Login.css';
import user_icon from '../Images/person.png';
import password_icon from '../Images/password.png';


const Login = () => {
    // State variables for username, password, and validation errors
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [errors, setErrors] = useState({});
  
    // Function to handle form submission
    const handleSubmit = (e) => {
      e.preventDefault();
  
      // Validate the form data
      const validationErrors = validateForm();
  
      if (Object.keys(validationErrors).length === 0) {
        // If no validation errors, perform login logic (e.g., send data to server)
        console.log('Login successful!');
      } else {
        // If there are validation errors, update the state with the errors
        setErrors(validationErrors);
      }
      console.log(errors);
      setUsername("");
      setPassword("");
    };
  
    // Function to validate form data
    const validateForm = () => {
      let validationErrors = {};
  
      // Validate username
      if (!username.trim()) {
        validationErrors.username = 'Username is required';
      }
  
      // Validate password
      if (!password.trim()) {
        validationErrors.password = 'Password is required';
      }
  
      return validationErrors;
    }; 

    return(
        <div className='container'>
            <form action='' onSubmit = {handleSubmit} >
            <div className='header'>
                <div className='text'>Login</div>
                <div className='underline'></div>
            </div>
            <div className='inputs'>
                <div className='input'>
                    <img src={user_icon} alt=''/>
                    <input type='text' placeholder='User Name' value={username} onChange={(e)=>setUsername(e.target.value)} required />
                    {errors.username && <p className="error">{errors.username}</p>}
                </div>
                <div className='input'>
                    <img src={password_icon} alt=''/>
                    <input type='password' placeholder='Password'  value={password} onChange={(e)=>setPassword(e.target.value)} required />
                    {errors.password && <p className="error">{errors.password}</p>}
                </div>
                
            </div>
            <div className='forgot-password'>Forget password? <span>Click Here!</span> </div>
            <div className='submit-container'>
                <button type='submit' className='submit' >Login</button>
            </div>
            </form>
        </div>
    )
}

export default Login;